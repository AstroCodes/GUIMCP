function varargout = GUIMCP(varargin)
% GUIMCP MATLAB code for GUIMCP.fig
%      GUIMCP, by itself, creates a new GUIMCP or raises the existing
%      singleton*.
%
%      H = GUIMCP returns the handle to a new GUIMCP or the handle to
%      the existing singleton*.
%
%      GUIMCP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUIMCP.M with the given input arguments.
%
%      GUIMCP('Property','Value',...) creates a new GUIMCP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUIMCP_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUIMCP_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUIMCP

% Last Modified by GUIDE v2.5 21-Sep-2016 15:03:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUIMCP_OpeningFcn, ...
                   'gui_OutputFcn',  @GUIMCP_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before GUIMCP is made visible.
function GUIMCP_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUIMCP (see VARARGIN)

% Choose default command line output for GUIMCP
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);
% UIWAIT makes GUIMCP wait for user response (see UIRESUME)
% uiwait(handles.figure1);



%% SEY BEGIN
% --- Executes on selection change in popupmenu2.
function popupmenu5_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val=get(hObject,'value');
%axes(handles.axes3);
switch val
%% PART I Fitting Parameters for primary electron energies.
    case 1
    %10 eV
    handles.C = 0.277; 
    
    case 2
    %30 eV
    handles.C = 0.136;
    
    case 3
    %100 eV
    handles.C = 0.126; 
    
    case 4
    %300 eV
    handles.C = 0.155; 
    
    case 5
    %550 eV
    handles.C = 0.2;
end
guidata(hObject,handles);


% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
% --- Executes during object creation, after setting all properties.
function popupmenu5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu11.
function popupmenu11_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val=get(hObject,'value');
%axes(handles.axes3);
switch val
%% PART I Fitting Parameters for primary electron energies.
    case 1
    %10 eV
    handles.tao = 0.985; 
    
    case 2
    %30 eV
    handles.tao = 0.99; 
    
    case 3
    %100 eV
    handles.tao = 1.16; 
    
    case 4
    %300 eV
    handles.tao = 0.85; 
    
    case 5
    %550 eV
    handles.tao = 0.909;
end
guidata(hObject,handles);
% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu11 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu11


% --- Executes during object creation, after setting all properties.
function popupmenu11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function popupmenu6_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val=get(hObject,'value');
%axes(handles.axes3);
switch val
    %% Associated Energy Values 
    case 1
    %Energy Scale for 10 eV
    handles.Es = 0:.1:10;% [eV] 
    
    case 2
    %Energy Scale for 30 eV
    handles.Es = 0:.1:30;% [eV] 
 
    case 3
    %Energy Scale for 100 eV
    handles.Es = 0:.1:100;
    
    case 4
    %Energy Scale for 300 eV
    handles.Es = 0:.1:300; 
    
    case 5
    %Energy Scale for 550 eV
    handles.Es = 0:.1:550; 
  
end
guidata(hObject,handles);
% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
% --- Executes during object creation, after setting all properties.
function popupmenu6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu12.
function popupmenu12_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val=get(hObject,'value');
%axes(handles.axes3);
switch val
    %% Associated Energy Values 
    case 1
    %Energy Scale for 10 eV
    %handles.E_s = 0:.1:10;% [eV] 
    handles.E0 = 1.57; % [eV]  
    
    case 2
    %Energy Scale for 30 eV
    %handles.E_s = 0:.1:30;% [eV] 
    handles.E0 = 1.9; % [eV]  
    
    case 3
    %Energy Scale for 100 eV
    %handles.E_s = 0:.1:100; 
    handles.E0 = 1.58;

    case 4
    %Energy Scale for 300 eV
    %handles.E_s = 0:.1:300; 
    handles.E0 = 2.1;

    case 5
    %Energy Scale for 550 eV
    %handles.E_s = 0:.1:550; 
    handles.E0 = 1.48;
    
end
guidata(hObject,handles);
% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu12 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu12


% --- Executes during object creation, after setting all properties.
function popupmenu12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%val=get(hObject,'value');
axes(handles.axes3);

E_s0 = ((handles.Es)./(handles.E0));
ES0 = log(E_s0);
ES01 = (ES0).^(2);

% True Secondary Electron Energy Dsitribution
FE_s = handles.C.* exp(-((ES01) ./ (2.* ((handles.tao).^(2)))));

%figure 
plot(handles.Es, FE_s, '.--red');
%axis([0 9 1e-3 .3])
%title('Secondary Electron Energy Distribution');
xlabel('Electron Energy (eV)');
ylabel('Secondary Electron Yield');
%legend('Value for 10 eV');
grid on;
    %otherwise
  
%end
%display('Curve Obtained');
TxtInfo = sprintf('Curve Obtained');
set(handles.TxtInfo, 'String', TxtInfo);
guidata(hObject,handles);




% --- Outputs from this function are returned to the command line.
function varargout = GUIMCP_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



%% CLOUD PARTICLES BEGIN

%% RADII
% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val=get(hObject,'value');
%axes(handles.axes3);
switch val
    case 1
        handles.radius = 1;
    case 2
        handles.radius = 2;
    case 3
        handles.radius = 3;
    case 4
        handles.radius = 4;
    case 5 
        handles.radius = 5;
end
guidata(hObject,handles);
% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% SIGMA
% --- Executes on selection change in popupmenu2.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val=get(hObject,'value');
%axes(handles.axes3);
switch val
    case 1
        handles.sigma = 1;
    case 2
        handles.sigma = 2;
    case 3
        handles.sigma = 3;
    case 4
        handles.sigma = 4;
    case 5 
        handles.sigma = 5;
end
guidata(hObject,handles);
% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% KERNEL SIZE
% --- Executes on selection change in popupmenu2.
function popupmenu4_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val=get(hObject,'value');
%axes(handles.axes3);
switch val
    case 1
        handles.KernelSize = [1,1];
    case 2
        handles.KernelSize = [3,3];
    case 3
        handles.KernelSize = [5,5];
    case 4
        handles.KernelSize = [7,7];
    case 5 
        handles.KernelSize = [9,9];
end
guidata(hObject,handles);
% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
% --- Executes during object creation, after setting all properties.
function popupmenu4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% GAIN
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val=get(hObject,'value');
axes(handles.axes2);

switch val
    case 1
        handles.Gain = 1e3;
    case 2
        handles.Gain = 1e4;
    case 3
        handles.Gain = 1e5;
    case 4
        handles.Gain = 1e6;
    case 5 
        handles.Gain = 1e7;
end
guidata(hObject,handles);
% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% CALCULATE CLOUD
% --- Executes on button press in pushbutton9.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes2);
Nmax = handles.Gain;

%Radius
R = handles.radius;

for n=1:Nmax
    
    %Generate random positions inside a circle
    r1(n)=R*rand(1,1);
    theta1(n)=2*pi*rand(1,1);
    
    %Polar to cartesian
    x1(n)=r1(n)*cos(theta1(n));
    y1(n)=r1(n)*sin(theta1(n));
   
end

%Convolve with Gaussian Kernel to simulate extinction
 sigma = handles.sigma;
 Ksize = handles.KernelSize;
 Gx = imgaussfilt(x1,sigma, 'FilterSize', Ksize);
 Gy = imgaussfilt(y1,sigma, 'FilterSize', Ksize);

%Plot Distribution
plot(Gx, Gy,'white.','MarkerSize',2)
set(gca, 'color', [0 0 0]);
xlabel('P(x)');
ylabel('P(y)'); 

%Background Limits
axis square;
axis([-1.1*R 1.1*R -1.1*R 1.1*R]);
set(gca,'xtick',[],'ytick',[]);

TxtInfo = sprintf('Cloud Particles Generated');
set(handles.TxtInfo, 'String', TxtInfo);
%display('Cloud Particles Generated');
guidata(hObject,handles);

%% SAVE CLOUD
% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%iterations = str2num(get(handles.edit3_Callback, 'String'));
% nu = str2double(get(handles.edit3, 'String'));
% nu1 = make_value_double(nu);
% set(handles.text20, 'String', nu1);
%% Save crop image

%[file,path]=uiputfile({'*.png','PNG'},'Save Image As');
I = getframe(handles.axes2);
[x]=frame2im(I); 
imwrite(x, 'output.png');
%I = getframe(handles.axes2); %Capture screen shot
%display('Cloud Particles Image Saved');
TxtInfo = sprintf('Cloud Particles Image Saved');
set(handles.TxtInfo, 'String', TxtInfo);

% I = imread('particles.png');
% % hint [xmin ymin width height].
% Crop = imcrop(I ,[74.5 6.5 220 216]);
% baseFileName = 'output.png';
% imwrite(Crop, baseFileName);
% display('Cropping Image Saved');
guidata(hObject,handles);


 


%% CONTOURS
function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% Hints: 

get(hObject,'String');% returns contents of edit1 as text
%str2double(get(hObject,'String')); %returns contents of edit1 as a double
% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% MU
function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
get(hObject,'String'); %returns contents of edit2 as text
% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



%% MASK
% --- Executes on selection change in popupmenu1.
function popupmenu7_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val=get(hObject,'value');

switch val
    case 1
        handles.mask = 'whole';
    case 2
        handles.mask = 'small';
    case 3
        handles.mask = 'medium';
    case 4
        handles.mask = 'large';
    otherwise
        error('unrecognized mask');   
end
guidata(hObject,handles);
% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
% --- Executes during object creation, after setting all properties.
function popupmenu7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on selection change in popupmenu9.
function popupmenu9_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu9 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu9
val=get(hObject,'value');

switch val
    case 1
        handles.ReSize = 100;
    case 2
        handles.ReSize = 150;
    case 3
        handles.ReSize = 200;
    case 4
        handles.ReSize = 250;
    case 5
        handles.ReSize = 300;
    case 6
        handles.ReSize = 350;
    case 7
        handles.ReSize = 400;
    case 8 
        handles.ReSize = 450;
    case 9
        handles.ReSize = 500;
    otherwise
        error('unrecognized mask');   
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% CUSTOM IMAGE LOAD
% --- Executes on button press in pushbutton18.
function pushbutton18_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename] = uigetfile({'output.png'},'File Selector');
handles.image = strcat(filename);
%image = strcat('segmentation.png');
axes(handles.axes4);
%display('Image Segmentation Loaded');
TxtInfo = sprintf('Custom image loaded, please rename as "output.png"');
set(handles.TxtInfo, 'String', TxtInfo);
imshow(handles.image, 'Parent', handles.axes4)
guidata(hObject,handles);


 %% CUSTOM MASK
% --- Executes on button press in pushbutton17.
function pushbutton17_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Select = get(handles.selector, 'SelectedObject');
axes(handles.axes4);
I = imread('output.png');
m = zeros(size(I));
Size = str2double(get(handles.edit8, 'String'));
x = Size;
m(x:size(I)-x,x:size(I)-x) = 1;

resize = handles.ReSize;
%mask = handles.mask;
num_iter = str2double(get(handles.edit3, 'String'));
mu = str2double(get(handles.edit4, 'String'));
method = 'chanvese';
chanvese(I,resize,m,num_iter,mu,method);

TxtInfo = sprintf('Contour obtained using a custom mask');
set(handles.TxtInfo, 'String', TxtInfo);
%Mask_Type = get(Select, 'String')
guidata(hObject,handles);

%% CHANVESE 
% --- Executes on button press in pushbutton1.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

axes(handles.axes4);
I = imread('output.png');

%% CORRECT FOR CUSTOM MASK
% mask = zeros(size(I,1),size(I,2));
% m = str2double(get(handles.edit8, 'String'));
% mask(m) = 1;

resize = handles.ReSize;
mask = handles.mask;
num_iter = str2double(get(handles.edit3, 'String'));
mu = str2double(get(handles.edit4, 'String'));
method = 'chanvese';

chanvese(I,resize,mask,num_iter,mu,method);

TxtInfo = sprintf('Contour Obtained');
set(handles.TxtInfo, 'String', TxtInfo);
guidata(hObject,handles);



%% CENTROID BEGIN
% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%[filename pathname] = uigetfile({'*.png'},'File Selector');
%image = strcat(pathname, filename);
image = strcat('segmentation.png');
axes(handles.axes1);
%display('Image Segmentation Loaded');
TxtInfo = sprintf('Image Segmentation Loaded');
set(handles.TxtInfo, 'String', TxtInfo);

%DisplayImage(image,handles.axes1);
imshow(image, 'Parent', handles.axes1)
% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I = imread('segmentation.png');
centroid(I);
TxtInfo = sprintf('Centroid Obtained');
set(handles.TxtInfo, 'String', TxtInfo);
%display('Centroid Obtained');





%% NEW BUTTONS

%% LOAD IMAGE PARTICLES
% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = strcat('output.png');
axes(handles.axes4);
%display('Cloud Particles Image Loaded');
TxtInfo = sprintf('Cloud Particles Image Loaded');
set(handles.TxtInfo, 'String', TxtInfo);

%DisplayImage(image,handles.axes1);
imshow(image, 'Parent', handles.axes4)
 

%% CLEAR BUTTON CENTROID
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 
 cla(handles.axes1, 'reset')
 %display('Axes Centroid Search Cleared');
 TxtInfo = sprintf('Axes Centroid Search Cleared');
 set(handles.TxtInfo, 'String', TxtInfo);

 %% DELETE BUTTON
 function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 
 delete('output.png', 'segmentation.png');
 TxtInfo = sprintf('Images Deleted');
 set(handles.TxtInfo, 'String', TxtInfo);
 
%% CLOSE BUTTON
% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 display('Application Closed');   
 %TxtInfo = sprintf('Application Closed');
 %set(handles.TxtInfo, 'String', TxtInfo);
 close(gcf);	

%% CLEAR BUTTON SEY
% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 
 cla(handles.axes3, 'reset');
 TxtInfo = sprintf('Axes Secondary Emission Yield Cleared');
 set(handles.TxtInfo, 'String', TxtInfo);
 
%% CLEAR BUTTON PARTICLES
% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 
 cla(handles.axes2, 'reset');
 TxtInfo = sprintf('Axes CLoud Particle Generator Cleared');
 set(handles.TxtInfo, 'String', TxtInfo);

%% CLEAR BUTTON SEGMENTATION PROCESS
% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 cla(handles.axes4, 'reset');
 TxtInfo = sprintf('Axes Active Contour Without Edges Cleared');
 set(handles.TxtInfo, 'String', TxtInfo);
 %display('Axes Active Contour Without Edges Cleared');



function TxtInfo_Callback(hObject, eventdata, handles)
% hObject    handle to TxtInfo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TxtInfo as text
%        str2double(get(hObject,'String')) returns contents of TxtInfo as a double


% --- Executes during object creation, after setting all properties.
function TxtInfo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TxtInfo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double
get(hObject,'String')
TxtInfo = sprintf('Custom mask: value of x => m(x:size(I)-x,x:size(I)-x) = 1');
set(handles.TxtInfo, 'String', TxtInfo);

% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
