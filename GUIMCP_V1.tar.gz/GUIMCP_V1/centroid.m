
function centroid(I)

tic
%Ibw = im2bw(I);
Ibw = imfill(I,'holes');

Ilabel = bwlabel(Ibw);
%stat = regionprops(Ilabel,'centroid');
stat = regionprops(Ilabel, I, {'Centroid','WeightedCentroid'});
imshow(I); 

hold on;

for x = 1: numel(stat)
    plot(stat(x).WeightedCentroid(1), stat(x).WeightedCentroid(2), 'redo');
    plot(stat(x).Centroid(1), stat(x).Centroid(2),'greenX');
end
title('Weighted (RED) and Unweighted (GREEN) Centroids');
stats = regionprops('table',Ilabel ,'Centroid', 'MajorAxisLength','MinorAxisLength')

%% http://www.mathworks.com/help/images/ref/regionprops.html

% centers = stats.Centroid;
% diameters = mean([stats.MajorAxisLength stats.MinorAxisLength],2);
% radii = diameters/2;
% hold on
% viscircles(centers,radii);
% hold off
%imwrite(stat,'centroid.png');
toc
end