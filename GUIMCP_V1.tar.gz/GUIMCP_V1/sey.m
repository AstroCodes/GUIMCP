%Universal Yield Curve, this formulae is for fitting porpouses with
%experimental data obtained by MCP experiment.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Secondary Electron Emission Properties 
%by definition [J. Scholtz]

function sey(E_s,E_0,C,tao)
E_p = 1e-2:.01:100; % 100 eV calculation only for example
E_m = 1.57; %
taoC = 1.16;
Constant = 0.126;
pm = E_p./E_m;
LnC = log(pm);
LnCC =  LnC.^2;
TaoC = 2.*(taoC.^2);
delta = exp(-(LnCC./TaoC));

figure 
semilogx(pm, delta,'.--red'); 
axis([0 1e1 1e-3 1.2])
title('Secondary Electron Emission Properties [J. Scholtz]');
xlabel('E_p/E_m');
ylabel('d/d_m');
legend('100 eV example; Gauss [log(E_p/E_m)]; Tao=1.6');
grid on; shg;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%PART I Fitting Parameters for primary electron energies.

% %10 eV
% C = 0.277; 
% tao = 0.985; 
% %100 eV
% C1 = 0.126; 
% tao1 = 1.16; 
% %30 eV
% C2 = 0.136;
% tao2 = 0.99; 
% %300 eV
% C3 = 0.155; 
% tao3 = 0.85; 
% %550 eV
% C4 = 0.2;
% tao4 = 0.909;


%PART II 
%Energy Scale for 10 eV
% E_s = 0:.1:10;% [eV] 
% E_0 = 1.57; % [eV]  
E_s0 = ((E_s)./(E_0));
ES0 = log(E_s0);
ES01 = (ES0).^(2);

%Energy Scale for 30 eV
% E_s2 = 0:.1:30;% [eV] 
% E_02 = 1.9; % [eV]  
E_s202 = ((E_s2)./(E_02));
ES2 = log(E_s202);
ES22 = (ES2).^(2);

%Energy Scale for 100 eV
% E_s1 = 0:.1:100; 
% E_01 = 1.58;
E_s101 = ((E_s1)./(E_01));
ES1 = log(E_s101);
ES21 = (ES1).^(2);

%Energy Scale for 300 eV
% E_s3 = 0:.1:300; 
% E_03 = 2.1;
E_s303 = ((E_s3)./(E_03));
ES3 = log(E_s303);
ES23 = (ES3).^(2);

%Energy Scale for 550 eV
% E_s4 = 0:.1:550; 
% E_04 = 1.48;
E_s404 = ((E_s4)./(E_04));
ES4 = log(E_s404);
ES24 = (ES4).^(2);


% True Secondary Electron Energy Dsitribution
FE_s = C.* exp(-((ES01) ./ (2.* ((tao).^(2)))));
FE_s1 = C1.* exp(-((ES21) ./ (2.* ((tao1).^(2)))));
FE_s2 = C2.* exp(-((ES22) ./ (2.* ((tao2).^(2)))));
FE_s3 = C3.* exp(-((ES23) ./ (2.* ((tao3).^(2)))));
FE_s4 = C4.* exp(-((ES24) ./ (2.* ((tao4).^(2)))));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plotting The Functions in function of eV.

figure 
subplot(2, 1, 1)
plot(E_s, FE_s, '.--red');
axis([0 9 1e-3 .3])
title('True Secondary Electron Energy Distribution');
xlabel('Electron Energy (eV)');
ylabel('Secondary Electron Yield');
legend('Value for 10 eV');
grid on;

subplot(2, 1, 2)
plot(E_s1, FE_s1, '.--red');
axis([0 35 1e-3 .15])
title('True Secondary Electron Energy Distribution');
xlabel('Electron Energy (eV)');
ylabel('Secondary Electron Yield');
legend('Value for 100 eV');
grid on;

figure 
subplot(3, 1, 1)
plot(E_s2, FE_s2, '.--red');
axis([0 35 1e-3 .15])
title('True Secondary Electron Energy Distribution');
xlabel('Electron Energy (eV)');
ylabel('Secondary Electron Yield');
legend('Value for 30 eV');
grid on;

subplot(3, 1, 2)
plot(E_s3, FE_s3, '.--red');
axis([0 35 1e-3 .2])
title('True Secondary Electron Energy Distribution');
xlabel('Electron Energy (eV)');
ylabel('Secondary Electron Yield');
legend('Value for 300 eV');
grid on;

subplot(3, 1, 3)
plot(E_s4, FE_s4, '.--red');
axis([0 35 1e-3 .25])
title('True Secondary Electron Energy Distribution');
xlabel('Electron Energy (eV)');
ylabel('Secondary Electron Yield');
legend('Value for 550 eV');
grid on;
end
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %Plotting semilogx in function of E_s/E0
% 
% figure 
% subplot(2, 1, 1)
% semilogx(E_s0, FE_s, '.--red');
% %axis([0 9 1e-3 .3])
% title('True Secondary Electron Energy Distribution');
% xlabel('E_s/E_0 (eV)');
% ylabel('Secondary Electron Yield');
% legend('Value for 10 eV');
% grid on;
% 
% subplot(2, 1, 2)
% semilogx(E_s101, FE_s1, '.--red');
% %axis([0 35 1e-3 .15])
% title('True Secondary Electron Energy Distribution');
% xlabel('E_s/E_0 (eV)');
% ylabel('Secondary Electron Yield');
% legend('Value for 100 eV');
% grid on;
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % All values in eV
% 
% figure
% semilogx(E_s, FE_s, '.--red', E_s2, FE_s2, '.--green', E_s1, FE_s1, '.--blue', E_s3, FE_s3, '.--black', E_s4, FE_s4, '.--magenta')
% axis([0 1e1 1e-3 .3])
% title('All Secondary Electron Energy Distribution');
% xlabel('Values for Energy (eV)');
% ylabel('Secondary Electron Yield');
% legend('10 ev', '30 eV', '100 eV', '300 eV', '550 eV');
% grid on;
% toc


