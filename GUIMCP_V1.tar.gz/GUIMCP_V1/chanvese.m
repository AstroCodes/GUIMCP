%==========================================================================
%   Active contour with Chan-Vese Method 
%   for image segmentation
%
%   Implemented by Yue Wu (yue.wu@tufts.edu)
%   Tufts University
%   Feb 2009
%
%   Modified by Angel Manrique (a.pozos@gmail.com)
% 
%   all rights reserved 
%   Last update 02/26/2009
%   Last update 08/06/2016
%--------------------------------------------------------------------------
%   Usage of varibles:
%   input: 
%       I           = any gray/double/RGB input image
%       mask        = initial mask, either customerlized or built-in
%       num_iter    = total number of iterations
%       mu          = weight of length term
%       method      = 'chanvese'
%
%   Types of built-in mask functions
%       'small'     = create a small circular mask
%       'medium'    = create a medium circular mask
%       'large'     = create a large circular mask
%       'whole'     = create a mask with holes around
%--------------------------------------------------------------------------
%
% Description: This code implements the paper: "Active Contours Without
% Edges" by Chan and Vese.
%
% I = imread('NAME.JPG'); or I = fitsread('NAME.fits');
% Customerlized Mask
% m = zeros(size(I,1),size(I,2));
% m(20:120,20:120) = 1;
% seg = chanvese(I,resize,m,500,0.1,'chan'); % ability on gray image
% Built-in Mask
% seg = chanvese(I,resize,'medium',400,0.02,'chan'); % ability on gray image
%-- End 
%==========================================================================

function seg = chanvese(I,resize,mask,num_iter,mu,method)
tic
%%
%-- Default settings
%   length term mu = 0.2 and method = 'chanvese'
  if(~exist('mu','var')) 
    mu=0.2; 
  end
  
  if(~exist('method','var')) 
    method = 'chanvese'; 
  end
%%
%-- Initializations on input image I and mask

%  resize original image
   s = resize./min(size(I,1),size(I,2)); % resize scale
   if s<1
       I = imresize(I,s);
   end
   
% mask settings
  if ischar(mask)
      switch lower (mask)
          case 'small'
              mask = maskc(I,'small');
          case 'medium'
              mask = maskc(I,'medium');
          case 'large'
              mask = maskc(I,'large');              
          case 'whole'
              mask = maskc(I,'whole'); 
          otherwise
              error('unrecognized mask');
      end 
  else
      if s<1
          mask = imresize(mask,s);
      end
      
      if size(mask,1)>size(I,1) || size(mask,2)>size(I,2)
          error('dimensions of mask unmathch those of the image')
      end
  end 

 
 switch lower(method)
     case 'chanvese'
        if size(I,3)== 3
            P = rgb2gray(uint8(I));
            P = double(P);   
        elseif size(I,3) == 2
            P = 0.5.*(double(I(:,:,1)) + double(I(:,:,2)));     
        else
            P = double(I);
        end
        
        layer = 1;
        P = double(I);  %P store the original i0125911801_UVM2_HRmage
        
     otherwise
        error('!invalid method')
end
%-- End Initializations on input image I and mask

%%
%--   Core function
 switch lower(method)
    case {'chanvese'}
        %-- SDF
        %   Get the distance map of the initial mask
        
        mask = mask(:,:,1);
        phi0 = bwdist(mask)-bwdist(1-mask)+im2double(mask)-.5; 
        
        %   initial force, set to eps to avoid division by zeros
        force = eps; 
        %-- End Initialization

        %-- Display settings
          %figure();
%           subplot(2,2,1); 
%           imshow(I); 
%           title('Input Image');
          
          %subplot(2,2,2); 
          %contour(flipud(phi0), [0,0], 'r','LineWidth',1); 
          %title('Initial contour');
          
          %subplot(2,2,3); 
          
          title('Segmentation');
        %-- End Display original image and mask
 %%       
        %-- Main loop
        
          for n=1:num_iter
              inidx = find(phi0>=0); % frontground index
              outidx = find(phi0<0); % background index
              force_image = 0; % initial image force for each layer 
              
              for i=1:layer
                  L = im2double(P(:,:,i)); % get one image component
                  c1 = sum(sum(L.*Heaviside(phi0)))/(length(inidx)+eps); % average inside of Phi0
                  c2 = sum(sum(L.*(1-Heaviside(phi0))))/(length(outidx)+eps); % verage outside of Phi0
                  force_image=-(L-c1).^2+(L-c2).^2+force_image; 
                  % sum Image Force on all components (used for vector image)
                  % if 'chan' is applied, this loop become one sigle code as a
                  % result of layer = 1
              end

              % calculate the external force of the image 
              force = mu*kappa(phi0)./max(max(abs(kappa(phi0))))+1/layer.*force_image;

              % normalized the force
              force = force./(max(max(abs(force))));

              % get stepsize dt
              dt=0.5;
              
              % get parameters for checking whether to stop
              old = phi0;
              phi0 = phi0+dt.*force;
              new = phi0;
              indicator = checkstop(old,new,dt);

              % intermediate output
              if(mod(n,20) == 0) 
                 showphi(I,phi0,n);  
              end
              
              if indicator % decide to stop or continue 
                  showphi(I,phi0,n);

                  %make mask from SDF
                  seg = phi0<=0; %-- Get mask from levelset

                  %subplot(2,2,4); 
                  %imshow(seg); 
                  %title('Final Segmentation');
                  return
              end
          end
          showphi(I,phi0,n);

%%
        %-- Make mask from SDF
          seg = phi0<=0; %-- Get mask from levelset
%           subplot(2,2,4); 
           imwrite(seg,'segmentation.png');
%           imshow(seg); 
%           title('Final Segmentation');

          

end
toc
