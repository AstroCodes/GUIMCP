%Program to create cloud of particles
function particles(gain,R,sigma,KernelSize)
%Number of particles
%gain=1e5;
%Radius
%R=1;

for n=1:gain
    
    %Generate random positions inside a circle
    r1(n)=R*rand(1,1);
    theta1(n)=2*pi*rand(1,1);
    
    %Polar to cartesian
    x1(n)=r1(n)*cos(theta1(n));
    y1(n)=r1(n)*sin(theta1(n));

end

%Convolve with Gaussian Kernel to simulate extinction
 %sigma = 1;
 %KernelSize = [3,3];
 Gx = imgaussfilt(x1,sigma, 'FilterSize', KernelSize);
 Gy = imgaussfilt(y1,sigma, 'FilterSize', KernelSize);

%Plot Distribution
%P = figure();
plot(Gx, Gy,'white.','MarkerSize',2)
%title('Gaussian Distribution For Random Particles');
%xlabel('P(x)');
%ylabel('P(y)'); 
%legend('random particles, with r=1 and n = 1e5')
set(gca, 'color', [0 0 0]);

%Background Limits
axis square;
axis([-1.1*R 1.1*R -1.1*R 1.1*R]);
set(gca,'xtick',[],'ytick',[]);
 %[291.5 113.5 652 646]
% axis off;
fig = gcf;
fig.Color = 'black';
fig.InvertHardcopy = 'off';
%saveas(gca,'particles.png');
%FileName = uiputfile('*.png','Save as');
%hgexport(gcf, 'particles.png', hgexport('factorystyle'), 'Format', 'png');


%% Save crop image
% Im = imread('particles.png');
% hint [xmin ymin width height].
%[263.5 77.5 718 714]
% Crop = imcrop(Im ,[122.5 33.5 337 339]);
% baseFileName = 'output.png';
% imwrite(Crop, baseFileName);

%imshow(Crop)
%Write & Read File
% fileID = fopen('Data.txt','w');
% fprintf(fileID,'%6s %12s\n','Gx','Gy');
% fprintf(fileID,'%6.8f %12.8f\n',Data);
% fclose(fileID);
% 
% A=importdata('Data.txt');
% GXX=A(:,1);
% GYY=A(:,2);
% figure
% plot(GXX, GYY, 'k.')
% axis square, grid on
end
